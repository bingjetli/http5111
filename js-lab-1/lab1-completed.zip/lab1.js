//document.onload = alert('Hello World');


let age = 25;

//number of days in a year
let nombre_du_jour_en_une_annee = 365;

//age in days
let age_en_les_jours = age * nombre_du_jour_en_une_annee;

//alert(age_en_les_jours + ' days');

let message1 = 'I am ';
let message2 = ' days old...more or less.';

alert(message1 + age_en_les_jours + message2);