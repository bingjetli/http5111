﻿//#### LAB 4 - FUNCTIONS ####
//PART 1:  PROGRAM ALERT FUNCTION


//################## CREATE YOUR FUNCTION
const coursePopup = (course_code, course_name) => {
    alert('The course code "' + course_code + '" is "' + course_name + '".');
};



//################## TEST YOUR FUNCTION
coursePopup('HTTP5111', 'Web Development 1');
coursePopup('HTTP5114', 'Workshops in Web Development 1');
coursePopup('IXD5105', 'Interaction Design Studio');
