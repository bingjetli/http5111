//LAB 3 - ARRAYS & LOOPS - PART 1


//ARRAY OF FRUITS
let la_liste_des_fruits = [
    'apples',
    'bananas',
    'oranges',
    'pears',
    'clementines',
    'guava',
    'pineapples'
];


//OUTPUT ONE FRUIT IN POPUP BOX
alert(
    'Here are the items in the fruit array: [' + 
    la_liste_des_fruits.toString() +
     '] \nThe 5th fruit in the list is ' +
      la_liste_des_fruits[0]
);
